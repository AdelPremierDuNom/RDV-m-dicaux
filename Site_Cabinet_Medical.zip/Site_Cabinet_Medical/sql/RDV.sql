DROP DATABASE IF EXISTS gestion_rdv;
CREATE DATABASE gestion_rdv;
USE gestion_rdv;
CREATE TABLE Patient(
    IdPatient INT AUTO_INCREMENT PRIMARY KEY,
    Nom VARCHAR(50),
    Prenom VARCHAR(50),
    DateNaissance DATE,
    Adresse VARCHAR(50),
    CodePostal VARCHAR(50),
    NumeroTel VARCHAR(50)
);
CREATE TABLE RDV(
    IdRDV INT AUTO_INCREMENT PRIMARY KEY,
    IdPatient int(3) not null,
    foreign key(IdPatient) references Patient(IdPatient),
    DateRDV DATE,
    HeureRDV TIME
);
CREATE TABLE Medecin(
    IdMedecin int AUTO_INCREMENT PRIMARY KEY,
    Nom VARCHAR(50),
    Prenom VARCHAR(50),
    DateNaissance DATE,
    NumeroTel VARCHAR(50),
    Bureau VARCHAR(50)
);
CREATE TABLE Prescription(
    IdPres INT AUTO_INCREMENT PRIMARY KEY,
    NbOrd INT(3),
    NbLettre INT(3),
    ArretTravail VARCHAR(50),
    DescriptionP VARCHAR(50)
);
CREATE TABLE Ordonnance(
    IdOrdo INT AUTO_INCREMENT PRIMARY KEY,
    Medicaments VARCHAR(50)
);