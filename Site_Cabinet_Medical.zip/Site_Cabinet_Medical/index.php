<?php
require_once("modele/modele.php");
?>

<!DOCTYPE html>
<html>

<head>
	<title> Site Cabinet Médical </title>
	<link rel="stylesheet" type="text/css" href="style.css" />

	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

	<nav class="navbar bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand">Doctolib</a>
    <form class="d-flex" role="search">
      <input class="form-control me-2" type="search" placeholder="Rechercher" aria-label="Search">
      <button class="btn btn-outline-success" type="submit">Rechercher</button>
    </form>
  </div>
	</nav>
</head>

<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	<center>
		<h1> Doctolib </h1>
		<a  href="index.php?page=1">
			<img class="logo" src="images/logo.jpg" height="100" width="100"> </a>
		<a  href="index.php?page=2">
			<img class="logo" src="images/patient.png" height="100" width="100"> </a>
		<a  href="index.php?page=3">
			<img class="logo" src="images/RDV.png" height="100" width="100"> </a>
		<a  href="index.php?page=4">
			<img class="logo" src="images/medecin.jpg" height="100" width="100"> </a>
        <a  href="index.php?page=5">
			<img class="logo" src="images/prescription.png" height="100" width="100"> </a>
        <a  href="index.php?page=6">
		    <img class="logo" src="images/ordonnance.png" height="100" width="100"> </a>
		<?php
		if (isset($_GET['page'])) {
			$page = $_GET['page'];
		} else {
			$page = 1;
		}
		switch ($page) {
			case 1:
				require_once("controleur/home.php");
				break;
			case 2:
				require_once("controleur/gestion_patient.php");
				break;
			case 3:
				require_once("controleur/gestion_RDV.php");
				break;
			case 4:
				require_once("controleur/gestion_medecin.php");
				break;
            case 5:
                require_once("controleur/gestion_prescription.php");
                break;
            case 6:
                require_once("controleur/gestion_ordonnance.php");
                break;
		}
		?>
		<br>
		<footer>
			<h2>Coordonnées</h2>
			<pre>                   Téléphone: 01 83 355 358                            Adresse: 54 QUAI CHARLES PASQUA 92300 LEVALLOIS-PERRET, France                            <a class="store" href="https://play.google.com/store/apps/details?id=fr.doctolib.www&hl=fr">     <img src="images/GooglePlay.avif" height="50" width="100"> </a><a class="store" href="https://apps.apple.com/fr/app/doctolib-trouvez-un-m%C3%A9decin/id925339063"> <img src="images/AppStore.png" height="50" width="100"></a></pre>
		</footer>
	</center>
</body>

</html>