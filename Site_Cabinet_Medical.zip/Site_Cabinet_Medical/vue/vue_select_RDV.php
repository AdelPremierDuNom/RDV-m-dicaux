<h2> Liste des RDV  </h2>

<table class="table table-info table-striped">
  <thead>
    <tr>
      <th scope="col">ID  RDV</th>
      <th scope="col">ID  Patient</th>
      <th scope="col">Date RDV</th>
      <th scope="col">Heure RDV</th>
      <th scope="col">Supprimer</th>
	  <th scope="col">Modifier</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
	  <td></td>
	  
    </tr>
  </tbody>

	<?php
		foreach($lesRDV as $unRDV){
			echo "<tr>";
			echo "<td>".$unRDV['IdRDV']."</td>";
      echo "<td>".$unRDV['IdPatient']."</td>";
			echo "<td>".$unRDV['DateRDV']."</td>";
            echo "<td>".$unRDV['HeureRDV']."</td>";
			echo "<td>";
			echo "<a href='index.php?page=3&action=suppr&IdRDV=" . $unRDV['IdRDV'] . "'><img src='images/suppr.png' height='50'/> </a>";
			echo "<td>";
			echo "<a href='index.php?page=3&action=edit&IdRDV=" . $unRDV['IdRDV'] . "'><img src='images/edit.png' height='50'/> </a>";
			"</td>";
			echo "</tr>";
		}
	?>
</table>