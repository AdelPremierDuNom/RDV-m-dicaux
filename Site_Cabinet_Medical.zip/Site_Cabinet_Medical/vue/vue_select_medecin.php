<h2> Liste des Medecins  </h2>

<table class="table table-info table-striped">
  <thead>
    <tr>
      <th scope="col">ID Medecin</th>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">DateNaissance</th>
	  <th scope="col">Numéro de téléphone</th>
	  <th scope="col">Bureau</th>
	  <th scope="col">Supprimer</th>
	  <th scope="col">Modifier</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
	  <td></td>
	  <td></td>
	  <td></td>
	  <td></td>
    </tr>
  </tbody>

	<?php
		foreach($lesMedecins as $unMedecin){
			echo "<tr>";
			echo "<td>".$unMedecin['IdMedecin']."</td>";
			echo "<td>".$unMedecin['Nom']."</td>";
            echo "<td>".$unMedecin['Prenom']."</td>";
            echo "<td>".$unMedecin['DateNaissance']."</td>";
            echo "<td>".$unMedecin['NumeroTel']."</td>";
            echo "<td>".$unMedecin['Bureau']."</td>";
			echo "<td>";
			echo "<a href='index.php?page=4&action=suppr&IdMedecin=" . $unMedecin['IdMedecin'] . "'><img src='images/suppr.png' height='50'/> </a>";
			echo "<td>";
			echo "<a href='index.php?page=4&action=edit&IdMedecin=" . $unMedecin['IdMedecin'] . "'><img src='images/edit.png' height='50'/> </a>";
			"</td>";
			echo "</tr>";
		}
	?>
</table>