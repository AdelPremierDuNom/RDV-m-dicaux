<form method="post">
	<table>
    	<tr>
			<td> Nombre d'ordonnances </td>
			<td> <input type="text" name="NbOrd" value="<?php if($laPrescription!=NULL)echo $laPrescription['NbOrd']?>"></td>
		</tr>
        <tr>
			<td> Nombre de lettres </td>
			<td> <input type="text" name="NbLettre" value="<?php if($laPrescription!=NULL)echo $laPrescription['NbLettre']?>"></td>
		</tr>
		<tr>
			<td> Arrêt de travail </td>
			<td> <input type="text" name="ArretTravail" value="<?php if($laPrescription!=NULL)echo $laPrescription['ArretTravail']?>"></td>
		</tr>
		<tr>
			<td> Description </td>
			<td> <input type="text" name="DescriptionP" value="<?php if($laPrescription!=NULL)echo $laPrescription['DescriptionP']?>"></td>
		</tr>
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit"
			<?php if($laPrescription!=null){
			echo 'name = "Modifier" value ="Modifier"';
			}
			else{
				echo 'name="Valider" value="Valider"';
			}?>> </td>
		</tr>
	</table> 
	<?php
	if($laPrescription !=null){
		echo "<input type='hidden' name='IdPres' value='".$laPrescription ['IdPres']."'>";
	}
	?>
</form>