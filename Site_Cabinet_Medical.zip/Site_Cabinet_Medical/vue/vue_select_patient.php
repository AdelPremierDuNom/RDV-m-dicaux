<h2> Liste des Patients  </h2>

<table class="table table-info table-striped">
  <thead>
    <tr>
      <th scope="col">ID patient</th>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">DateNaissance</th>
	  <th scope="col">Adresse</th>
	  <th scope="col">CodePostal</th>
	  <th scope="col">NumeroTel</th>
	  <th scope="col">Supprimer</th>
	  <th scope="col">Modifier</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
	  <td></td>
	  <td></td>
	  <td></td>
	  <td></td>
	  <td></td>
	  
    </tr>
  </tbody>
	<?php
		foreach($lesPatients as $unPatient){
			echo "<tr>";
			echo "<td>".$unPatient['IdPatient']."</td>";
			echo "<td>".$unPatient['Nom']."</td>";
			echo "<td>".$unPatient['Prenom']."</td>";
			echo "<td>".$unPatient['DateNaissance']."</td>";
			echo "<td>".$unPatient['Adresse']."</td>";
			echo "<td>".$unPatient['CodePostal']."</td>";
			echo "<td>".$unPatient['NumeroTel']."</td>";
			echo "<td>";
			echo "<a href='index.php?page=2&action=suppr&IdPatient=" . $unPatient['IdPatient'] . "'><img src='images/suppr.png' height='50'/> </a>";
			echo "<td>";
			echo "<a href='index.php?page=2&action=edit&IdPatient=" . $unPatient['IdPatient'] . "'><img src='images/edit.png' height='50'/> </a>";
			"</td>";
			echo "</tr>";
		}
	?>
</table>