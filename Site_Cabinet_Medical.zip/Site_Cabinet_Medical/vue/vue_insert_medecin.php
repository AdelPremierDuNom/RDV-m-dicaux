<form method="post">
	<table>
    	<tr>
			<td> Nom </td>
			<td> <input type="text" name="Nom" value="<?php if($leMedecin!=NULL)echo $leMedecin['Nom']?>"></td>
		</tr>
        <tr>
			<td> Prenom </td>
			<td> <input type="text" name="Prenom" value="<?php if($leMedecin!=NULL)echo $leMedecin['Prenom']?>"></td>
		</tr>
		<tr>
			<td> Date de naissance </td>
			<td> <input type="date" name="DateNaissance" placeholder="dd-mm-yyyy" value="<?php if($leMedecin!=NULL)echo $leMedecin['DateNaissance']?>"></td>
		</tr>
		
        <tr>
			<td> Numero de téléphone </td>
			<td> <input type="text" name="NumeroTel" value="<?php if($leMedecin!=NULL)echo $leMedecin['NumeroTel']?>"></td>
		</tr>
        <tr>
			<td> Bureau </td>
			<td> <input type="text" name="Bureau" value="<?php if($leMedecin!=NULL)echo $leMedecin['Bureau']?>"></td>
		</tr>
	
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit"
			<?php if($leMedecin!=null){
			echo 'name = "Modifier" value ="Modifier"';
			}
			else{
				echo 'name="Valider" value="Valider"';
			}?>> </td>
		</tr>
	</table> 
	<?php
	if($leMedecin !=null){
		echo "<input type='hidden' name='IdMedecin' value='".$leMedecin ['IdMedecin']."'>";
	}
	?>
</form>