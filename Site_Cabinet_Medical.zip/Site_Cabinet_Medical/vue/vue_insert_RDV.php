<form method="post">
	<table>
		<tr>
			<td> Id Patient </td>
			<td> <input type="text" name="IdPatient" value="<?php if($leRDV!=NULL)echo $leRDV['IdPatient']?>"></td>
		</tr>
		<tr>
			<td> Date </td>
			<td> <input type="date" name="DateRDV" placeholder="dd-mm-yyyy" value="<?php if($leRDV!=NULL)echo $leRDV['DateRDV']?>"></td>
		</tr>
        <tr>
			<td> Heure </td>
			<td> <input type="time" name="HeureRDV" placeholder="hh:mm" value="<?php if($leRDV!=NULL)echo $leRDV['HeureRDV']?>"></td>
		</tr>
		
        
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler" > </td>
			<td> <input type="submit"
			<?php if($leRDV!=null){
			echo 'name = "Modifier" value ="Modifier"';
			}
			else{
				echo 'name="Valider" value="Valider"';
			}?>> </td>
		</tr>
	</table> 
	<?php
	if($leRDV !=null){
		echo "<input type='hidden' name='IdRDV' value='".$leRDV ['IdRDV']."'>";
	}
	?>
</form>