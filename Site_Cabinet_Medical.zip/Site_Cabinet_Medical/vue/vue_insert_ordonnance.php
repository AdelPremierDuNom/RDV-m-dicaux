<form method="post">
	<table>
    	<tr>
			<td> Médicaments </td>
			<td> <input type="text" name="Medicaments" value="<?php if($leOrdonnance!=NULL)echo $leOrdonnance['Medicaments']?>"></td>
		</tr>


	
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit" 
			<?php if($leOrdonnance!=null){
			echo 'name = "Modifier" value ="Modifier"';
			}
			else{
				echo 'name="Valider" value="Valider"';
			}?>> </td>
		</tr>
	</table> 
	<?php
	if($leOrdonnance !=null){
		echo "<input type='hidden' name='IdOrdo' value='".$leOrdonnance ['IdOrdo']."'>";
	}
	?>
</form>