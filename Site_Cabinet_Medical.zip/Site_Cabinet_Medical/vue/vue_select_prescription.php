<h2> Liste des Prescriptions  </h2>

<table class="table table-info table-striped">
  <thead>
    <tr>
      <th scope="col">ID  Prescriptions</th>
      <th scope="col">NbOrd</th>
      <th scope="col">NbLettre</th>
      <th scope="col">Arret Travail</th>
	  <th scope="col">DescriptionP</th>
	  <th scope="col">Supprimer</th>
	  <th scope="col">Modifier</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
	  <td></td>
	  <td></td>
	  <td></td>
	  
    </tr>
  </tbody>
		
	</tr>
	<?php
		foreach($lesPrescriptions as $unePrescription){
			echo "<tr>";
			echo "<td>".$unePrescription['IdPres']."</td>";
			echo "<td>".$unePrescription['NbOrd']."</td>";
            echo "<td>".$unePrescription['NbLettre']."</td>";
			echo "<td>".$unePrescription['ArretTravail']."</td>";
			echo "<td>".$unePrescription['DescriptionP']."</td>";
			echo "<td>";
			echo "<a href='index.php?page=5&action=suppr&IdPres=" . $unePrescription['IdPres'] . "'><img src='images/suppr.png' height='50'/> </a>";
			echo "<td>";
			echo "<a href='index.php?page=5&action=edit&IdPres=" . $unePrescription['IdPres'] . "'><img src='images/edit.png' height='50'/> </a>";
			"</td>";
			echo "</tr>";
		}
	?>
</table>