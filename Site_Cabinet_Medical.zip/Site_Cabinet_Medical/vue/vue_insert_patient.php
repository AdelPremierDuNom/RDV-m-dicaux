<form method="post">
	<table>
		<tr>
			<td> Nom </td>
			<td> <input type="text" name="Nom" value="<?php if($lePatient!=NULL)echo $lePatient['Nom']?>"></td>
		</tr>
        <tr>
			<td> Prenom </td>
			<td> <input type="text" name="Prenom" value="<?php if($lePatient!=NULL)echo $lePatient['Prenom']?>"></td>
		</tr>
		<tr>
			<td> Date de naissance </td>
			<td> <input type="date" name="DateNaissance" placeholder="dd-mm-yyyy" value="<?php if($lePatient!=NULL)echo $lePatient['DateNaissance']?>"></td>
		</tr>
		<tr>
			<td> Adresse </td>
			<td> <input type="text" name="Adresse" value="<?php if($lePatient!=NULL)echo $lePatient['Adresse']?>"></td>
		</tr>
		<tr>
			<td> Code Postal </td>
			<td> <input type="text" name="CodePostal" value="<?php if($lePatient!=NULL)echo $lePatient['CodePostal']?>"></td>
		</tr>
        <tr>
			<td> Numero de téléphone </td>
			<td> <input type="text" name="NumeroTel" value="<?php if($lePatient!=NULL)echo $lePatient['NumeroTel']?>"></td>
		</tr>
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit"
			<?php if($lePatient!=null){
			echo 'name = "Modifier" value ="Modifier"';
			}
			else{
				echo 'name="Valider" value="Valider"';
			}?>> </td>
		</tr>
	</table> 
	<?php
	if($lePatient !=null){
		echo "<input type='hidden' name='IdPatient' value='".$lePatient ['IdPatient']."'>";
	}
	?>
</form>