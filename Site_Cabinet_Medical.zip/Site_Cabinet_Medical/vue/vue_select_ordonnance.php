<h2> Liste des Ordonnances  </h2>

<table class="table table-info table-striped">
  <thead>
    <tr>
      <th scope="col">ID Ordo</th>
      <th scope="col">Medicaments</th>
      <th scope="col">Supprimer</th>
      <th scope="col">Modifier</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
	<?php
		foreach($lesOrdonnances as $uneOrdonnance){
			echo "<tr>";
			echo "<td>".$uneOrdonnance['IdOrdo']."</td>";
			echo "<td>".$uneOrdonnance['Medicaments']."</td>";
			echo "<td>";
			echo "<a href='index.php?page=6&action=suppr&IdOrdo=" . $uneOrdonnance['IdOrdo'] . "'><img src='images/suppr.png' height='50'/> </a>";
			echo "<td>";
			echo "<a href='index.php?page=6&action=edit&IdOrdo=" . $uneOrdonnance['IdOrdo'] . "'><img src='images/edit.png' height='50'/> </a>";
			"</td>";
			echo "</tr>";
		}
	?>
</table>