<?php

/** Co et Déco de mysql **************/
//fonction qui connecte à mysql
function connexion(){
    $connexion = mysqli_connect("localhost","root","","gestion_RDV");
    if($connexion == null){
        echo "Erreur de connexion au serveur MYSQL.";
    }
    return $connexion;
}

//fonction qui déco de mysql
function deconnexion($connexion){
    mysqli_close($connexion);
}
/** Fin Co et Déco de mysql *************/

/** Gestion des patients **************/
//fonction pour inserer un patient dans la table patient base de donnée
function insertPatient($tab){
    $requete = "insert into Patient values (null,'"
        .$tab['Nom']."','"
        .$tab['Prenom']."','"
        .$tab['DateNaissance']."','"
        .$tab['Adresse']."','"
        .$tab['CodePostal']."','"
        .$tab['NumeroTel']."');";

    $con = connexion(); //ici on dit que $con contient la fonction connexion
    mysqli_query($con, $requete);//là on se connecte puis on execute $requete qui contient notre insert quelque chose
    deconnexion($con);//simple, on se déco de mysql
}

//La fonction pour afficher le contenu de la table patient
function selectAllPatients(){
    $requete = "select * from Patient;";//On affiche tout le contenu de la table patient
    $con = connexion();
    $lesPatients = mysqli_query($con,$requete);//On se co à mysql puis on fait select *
    deconnexion($con);
    return $lesPatients;
}

//La fonction pour supprimer un patient
function deletePatient($IdPatient){
    $requete = "delete from Patient where IdPatient = ".$IdPatient.";";//supprime la ligne qui a l'id renseigné sur le formulaire
    $con = connexion();
    mysqli_query($con,$requete);
    deconnexion($con);
}

//La fonction qui sert à modifier une ligne
function updatePatient($tab){
    $requete = "update Patient set 
    Nom ='".$tab['Nom']."',
    Prenom = '".$tab['Prenom']."',
    DateNaissance = '".$tab['DateNaissance']."',
    Adresse = '".$tab['Adresse']."',
    CodePostal = '".$tab['CodePostal']."',
    NumeroTel = '".$tab['NumeroTel']."'
    where IdPatient = ".$tab['IdPatient'];

    $con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);
    
}

//La fonction qui sert à... à quoi en fait ? faut que je trouve à quoi ça sert
function selectWherePatient($IdPatient){
    $requete = "select * from Patient where IdPatient =".$IdPatient;
    $con = connexion();
    $resultats = mysqli_query($con, $requete);
    $lePatient = mysqli_fetch_assoc($resultats);
    deconnexion ($con);
    return $lePatient;
}
/** Fin Gestion des patients *************/

/** Gestion des RDV **************/
function insertRDV($tab){
    $requete = "insert into RDV values (null,'"
        .$tab['IdPatient']."','"
        .$tab['DateRDV']."','"
        .$tab['HeureRDV']."');";

    $con = connexion(); 
    mysqli_query($con, $requete);
    deconnexion($con);
}

function selectAllRDV(){
    $requete = "select * from RDV;";
    $con = connexion();
    $lesRDV = mysqli_query($con,$requete);
    deconnexion($con);
    return $lesRDV;
}

function deleteRDV($IdRDV){
    $requete = "delete from RDV where IdRDV = ".$IdRDV.";";
    $con = connexion();
    mysqli_query($con,$requete);
    deconnexion($con);
}

function updateRDV($tab){
    $requete = "update RDV set 
    IdPatient ='".$tab['IdPatient']."',
    DateRDV ='".$tab['DateRDV']."',
    HeureRDV = '".$tab['HeureRDV']."'
    where IdRDV = ".$tab['IdRDV'];

    $con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);

}

function selectWhereRDV($IdRDV){
    $requete = "select * from RDV where IdRDV =".$IdRDV;
    $con = connexion();
    $resultats = mysqli_query($con, $requete);
    $leRDV = mysqli_fetch_assoc($resultats);
    deconnexion ($con);
    return $leRDV;
}
/** Fin Gestion des RDV *************/

/** Gestion des Medecins **************/
function insertMedecin($tab){
    $requete = "insert into Medecin values (null,'"
        .$tab['Nom']."','"
        .$tab['Prenom']."','"
        .$tab['DateNaissance']."','"
        .$tab['NumeroTel']."','"
        .$tab['Bureau']."');";

    $con = connexion(); 
    mysqli_query($con, $requete);
    deconnexion($con);
}

function selectAllMedecins(){
    $requete = "select * from Medecin;";
    $con = connexion();
    $lesMedecins = mysqli_query($con,$requete);
    deconnexion($con);
    return $lesMedecins;
}

function deleteMedecin($IdMedecin){
    $requete = "delete from Medecin where IdMedecin = ".$IdMedecin.";";
    $con = connexion();
    mysqli_query($con,$requete);
    deconnexion($con);
}

function updateMedecin($tab){
    $requete = "update Medecin set 
    Nom ='".$tab['Nom']."',
    Prenom = '".$tab['Prenom']."',
    DateNaissance = '".$tab['DateNaissance']."',
    NumeroTel = '".$tab['NumeroTel']."',
    Bureau = '".$tab['Bureau']."'
    where IdMedecin = ".$tab['IdMedecin'];

    $con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);
}

function selectWhereMedecin($IdMedecin){
    $requete = "select * from Medecin where IdMedecin =".$IdMedecin;
    $con = connexion();
    $resultats = mysqli_query($con, $requete);
    $leMedecin = mysqli_fetch_assoc($resultats);
    deconnexion ($con);
    return $leMedecin;
}
/** Fin Gestion des Medecins *************/

/** Gestion des Prescriptions **************/
function insertPrescription($tab){
    $requete = "insert into Prescription values (null,'"
        .$tab['NbOrd']."','"
        .$tab['NbLettre']."','"
        .$tab['ArretTravail']."','"
        .$tab['DescriptionP']."');";

    $con = connexion(); 
    mysqli_query($con, $requete);
    deconnexion($con);
}

function selectAllPrescriptions(){
    $requete = "select * from Prescription;";
    $con = connexion();
    $lesPrescriptions = mysqli_query($con,$requete);
    deconnexion($con);
    return $lesPrescriptions;
}

function deletePrescription($IdPres){
    $requete = "delete from Prescription where IdPres = ".$IdPres.";";
    $con = connexion();
    mysqli_query($con,$requete);
    deconnexion($con);
}

function updatePrescription($tab){
    $requete = "update Prescription set 
    NbOrd ='".$tab['NbOrd']."',
    NbLettre = '".$tab['NbLettre']."',
    ArretTravail = '".$tab['ArretTravail']."',
    DescriptionP = '".$tab['DescriptionP']."'
    where IdPres = ".$tab['IdPres'];

    $con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);
}

function selectWherePrescription($IdPres){
    $requete = "select * from Prescription where IdPres =".$IdPres;
    $con = connexion();
    $resultats = mysqli_query($con, $requete);
    $lePrescription = mysqli_fetch_assoc($resultats);
    deconnexion ($con);
    return $lePrescription;
}
/** Fin Gestion des Prescriptions *************/

/** Gestion des Ordonnances **************/
function insertOrdonnance($tab){
    $requete = "insert into Ordonnance values (null,'"
        .$tab['Medicaments']."');";

    $con = connexion(); 
    mysqli_query($con, $requete);
    deconnexion($con);
}

function selectAllOrdonnances(){
    $requete = "select * from Ordonnance;";
    $con = connexion();
    $lesOrdonnances = mysqli_query($con,$requete);
    deconnexion($con);
    return $lesOrdonnances;
}

function deleteOrdonnance($IdOrdo){
    $requete = "delete from Ordonnance where IdOrdo = ".$IdOrdo.";";
    $con = connexion();
    mysqli_query($con,$requete);
    deconnexion($con);
}

function updateOrdonnance($tab){
    $requete = "update Ordonnance set 
    Medicaments ='".$tab['Medicaments']."'
    where IdOrdo = ".$tab['IdOrdo'];

    $con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);
}

function selectWhereOrdonnance($IdOrdo){
    $requete = "select * from Ordonnance where IdOrdo =".$IdOrdo;
    $con = connexion();
    $resultats = mysqli_query($con, $requete);
    $leOrdonnance = mysqli_fetch_assoc($resultats);
    deconnexion ($con);
    return $leOrdonnance;
}
/** Fin Gestion des Ordonnances *************/