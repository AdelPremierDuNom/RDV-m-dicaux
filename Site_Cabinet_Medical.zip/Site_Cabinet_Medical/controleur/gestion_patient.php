<h2> Gestion des Patients </h2>

<?php
$lePatient=null;
if((isset($_GET['action']))&&(isset($_GET['IdPatient'])))
{
	$action = $_GET['action'];
	$IdPatient = $_GET['IdPatient'];
	switch ($action){
		case "suppr": deletePatient ($IdPatient); 
		break;
		case"edit":$lePatient = selectWherePatient($IdPatient);
		break;
	}
}
require_once("vue/vue_insert_patient.php");
if (isset($_POST['Valider'])) {
	//insertion du patient dans la table patient
	insertPatient($_POST);
	echo "<br> Insertion du patient réussie.";
}
if(isset($_POST['Modifier']))
{
	updatePatient ($_POST);
	//recharger la page
	header(("Location: index.php?page=2"));
}
$lesPatients = selectAllPatients();
require_once("vue/vue_select_patient.php");
if (isset($_POST['Modifier'])) {
	updatePatient($_POST); // recharger la page
	header(("location: index.php?page=2"));
}
?>