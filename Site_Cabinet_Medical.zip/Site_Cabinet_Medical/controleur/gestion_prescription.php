<h2> Gestion des Prescriptions </h2>

<?php
$laPrescription=null;
if((isset($_GET['action']))&&(isset($_GET['IdPres'])))
{
	$action = $_GET['action'];
	$IdPres = $_GET['IdPres'];
	switch ($action){
		case "suppr": deletePrescription ($IdPres); 
		break;
		case"edit":$laPrescription = selectWherePrescription($IdPres);
		break;
	}
}
require_once("vue/vue_insert_prescription.php");
if (isset($_POST['Valider'])) {
	//insertion du prescription dans la table prescription
	insertPrescription($_POST);
	echo "<br> Insertion du prescription réussie.";
}
if(isset($_POST['Modifier']))
{
	updatePrescription ($_POST);
	//recharger la page
	header(("Location: index.php?page=5"));
}
$lesPrescriptions = selectAllPrescriptions();
require_once("vue/vue_select_prescription.php");
if (isset($_POST['Modifier'])) {
	updatePrescription($_POST); // recharger la page
	header(("location: index.php?page=5"));
}
?>