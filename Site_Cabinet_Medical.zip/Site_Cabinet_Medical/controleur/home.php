<div id="home">
<h2> Bienvenue au Cabinet Médical </h2>
<br>
<p id="p"> Doctolib est une entreprise française fondée en 2013 par Franck Tetzlaff et Stanislas Niox-Chateau qui distribue en France, en Italie et en Allemagne, une application de gestion des rendez-vous réservée aux professionnels de la santé ainsi qu'un service de prise de rendez-vous en ligne, destiné aux patients. Le site web est principalement dédié aux services des professionnels de santé, exerçant dans un cadre réglementé ou non, une médecine conventionnelle ou non. </p>
<br>
<a href="https://www.doctolib.fr/cabinet-medical"> Visiter le site de Doctolib </a>
<br>
<a href="https://www.doctolib.fr/cabinet-medical">
	<img src="images/Doctolib.png" id="doctolib" height="450" width="700"> </a>
<br>
<br>
</div>