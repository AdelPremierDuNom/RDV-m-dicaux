<h2> Gestion des Medecins </h2>

<?php
$leMedecin=null;
if(isset($_GET['action']) && isset($_GET['IdMedecin']))
{
	$action = $_GET['action'];
	 
	$IdMedecin = $_GET['IdMedecin'];
	switch ($action){
		case "suppr": deleteMedecin ($IdMedecin); 
		break;
		case"edit":$leMedecin = selectWhereMedecin($IdMedecin);
		break;
	}
}
require_once("vue/vue_insert_medecin.php");
if (isset($_POST['Valider'])) {
	//insertion du medecin dans la table medecin
	insertMedecin($_POST);
	echo "<br> Insertion du medecin réussie.";
}
if(isset($_POST['Modifier']))
{
	updateMedecin ($_POST);
	//recharger la page
	header(("Location: index.php?page=4"));
}
$lesMedecins = selectAllMedecins();
require_once("vue/vue_select_medecin.php");
if (isset($_POST['Modifier'])) {
	updateMedecin($_POST); // recharger la page
	header(("location: index.php?page=4"));
}
?>