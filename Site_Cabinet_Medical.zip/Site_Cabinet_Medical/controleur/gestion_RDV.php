<h2> Gestion des RDV </h2>

<?php
$leRDV=null;
if((isset($_GET['action']))&&(isset($_GET['IdRDV'])))
{
	$action = $_GET['action'];
	$IdRDV = $_GET['IdRDV'];
	switch ($action){
		case "suppr": deleteRDV($IdRDV); 
		break;
		case"edit":$leRDV = selectWhereRDV($IdRDV);
		break;
	}
}
require_once("vue/vue_insert_RDV.php");
if (isset($_POST['Valider'])) {
	//insertion du RDV dans la table RDV
	insertRDV($_POST);
	echo "<br> Insertion du RDV réussie.";
}
if(isset($_POST['Modifier']))
{
	updateRDV ($_POST);
	//recharger la page
	header(("Location: index.php?page=3"));
}
$lesRDV = selectAllRDV();
require_once("vue/vue_select_RDV.php");
if (isset($_POST['Modifier'])) {
	updateRDV($_POST); // recharger la page
	header(("location: index.php?page=3"));
}
?>