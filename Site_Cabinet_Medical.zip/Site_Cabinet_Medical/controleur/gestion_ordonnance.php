<h2> Gestion des Ordonnances </h2>

<?php
$leOrdonnance=null;
if((isset($_GET['action']))&&(isset($_GET['IdOrdo'])))
{
	$action = $_GET['action'];
	$IdOrdo = $_GET['IdOrdo'];
	switch ($action){
		case "suppr": deleteOrdonnance ($IdOrdo); 
		break;
		case"edit":$leOrdonnance = selectWhereOrdonnance($IdOrdo);
		break;
	}
}
require_once("vue/vue_insert_ordonnance.php");
if (isset($_POST['Valider'])) {
	//insertion de l'ordonnance dans la table ordonnance
	insertOrdonnance($_POST);
	echo "<br> Insertion de l'ordonnance réussie.";
}
if(isset($_POST['Modifier']))
{
	updateOrdonnance ($_POST);
	//recharger la page
	header(("Location: index.php?page=6"));
}
$lesOrdonnances = selectAllOrdonnances();
require_once("vue/vue_select_ordonnance.php");
if (isset($_POST['Modifier'])) {
	updateOrdonnance($_POST); // recharger la page
	header(("location: index.php?page=6"));
}
?>